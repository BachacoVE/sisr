-- Function: rrhh_liq_mae_bono_incentivo_ahorro(double precision)

-- DROP FUNCTION rrhh_liq_mae_bono_incentivo_ahorro(double precision);

CREATE OR REPLACE FUNCTION rrhh_liq_mae_bono_incentivo_ahorro(horas_trabajadas double precision)
  RETURNS double precision AS
$BODY$
	DECLARE 
	incentivo_ahorro DOUBLE PRECISION;

        BEGIN

	    IF
	        horas_trabajadas < 1496
	    THEN
                incentivo_ahorro = (horas_trabajadas * 4000)/1496;
        ELSE
	        incentivo_ahorro = 4000;
	    END IF;
		
		RETURN incentivo_ahorro;    
	    
        END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION rrhh_liq_mae_bono_incentivo_ahorro(double precision)
  OWNER TO openerp;
