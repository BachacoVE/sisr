-- Function: rrhh_liq_mae_cant_dias_interes(date)

-- DROP FUNCTION rrhh_liq_mae_cant_dias_interes(date);

CREATE OR REPLACE FUNCTION rrhh_liq_mae_cant_dias_interes(fecha_fin date)
  RETURNS double precision AS
$BODY$
	DECLARE cant_dias_interes DOUBLE PRECISION;
        BEGIN
			SELECT cantidad_dias INTO  cant_dias_interes
                FROM for_pis_mae_tasas_bcv_prestaciones a
                WHERE a.mes = date_part('month', fecha_fin);               		
		RETURN cant_dias_interes;
        END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION rrhh_liq_mae_cant_dias_interes(date)
  OWNER TO openerp;
