-- Function: rrhh_liq_mae_ultimo_salario_mensual_promediado(integer, integer, integer, integer, double precision)

-- DROP FUNCTION rrhh_liq_mae_ultimo_salario_mensual_promediado(integer, integer, integer, integer, double precision);

CREATE OR REPLACE FUNCTION rrhh_liq_mae_ultimo_salario_mensual_promediado(maestro integer, meses integer, modalidad integer, total_horas integer, valor_hora double precision)
  RETURNS double precision AS
$BODY$
	DECLARE ultimo_salario DOUBLE PRECISION;
        BEGIN
		IF (modalidad = 5) THEN
			ultimo_salario = (total_horas * valor_hora);
		ELSE
			SELECT sum(monto_pago) INTO ultimo_salario 
			FROM for_pis_mae_consolidado_detalle cd
			INNER JOIN for_pis_mae_consolidado cm
			ON cm.id = cd.consolidado_id
			WHERE cd.maestro_id = maestro
			AND cm.codigo LIKE 'Cons%'
			GROUP BY cd.maestro_id, cd.consolidado_id
			ORDER BY cd.consolidado_id DESC
			LIMIT 1;
		END IF;
		
		IF meses = 0 THEN
			RETURN (ultimo_salario - ultimo_salario);
		ELSE
			IF (modalidad = 3) THEN
				-- Calculo de Ultimo Salario/ meses de antiguedad. Cada mes representa veinte (20) días
				RETURN (ultimo_salario / meses);
			ELSE
				-- Si la modalidad = 4 (Por Horas) o la modalidad = 5 (Maestros Básica), entonces:
				-- Calculo de Ultimo Salario/horas trabajadas * 30
				RETURN ((ultimo_salario/total_horas) * 30);
			END IF;
		END IF;		
        END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION rrhh_liq_mae_ultimo_salario_mensual_promediado(integer, integer, integer, integer, double precision)
  OWNER TO openerp;
