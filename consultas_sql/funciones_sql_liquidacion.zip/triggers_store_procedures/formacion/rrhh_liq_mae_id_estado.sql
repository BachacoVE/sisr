-- Function: rrhh_liq_mae_id_estado(integer)

-- DROP FUNCTION rrhh_liq_mae_id_estado(integer);

CREATE OR REPLACE FUNCTION rrhh_liq_mae_id_estado(id_dependencia integer)
  RETURNS integer AS
$BODY$
	DECLARE
		dependencia CHAR;
		id_estado INTEGER;
        BEGIN
		SELECT
		(CASE WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES AMAZONAS' THEN '1'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES ANZOATEGUI' THEN '2'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES APURE' THEN '3'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES ARAGUA' THEN '4'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES BARINAS' THEN '5'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES BOLIVAR' THEN '6'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES CARABOBO' THEN '7'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES COJEDES' THEN '8'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES DELTA AMACURO' THEN '9'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES DISTRITO CAPITAL' THEN '10'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES FALCON' THEN '11'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES GUARICO' THEN '12'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES LARA' THEN '13'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES MERIDA' THEN '14'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES MIRANDA' THEN '15'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES MONAGAS' THEN '16'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES NUEVA ESPARTA' THEN '17'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES PORTUGUESA' THEN '18'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES SUCRE' THEN '19'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES TACHIRA' THEN '20'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES TRUJILLO' THEN '21'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES VARGAS' THEN '22'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES YARACUY' THEN '23'
			WHEN d.dependencia_administrativa='GERENCIA REGIONAL INCES ZULIA' THEN '24'
			ELSE '99'
		END)::integer AS "cod_edo" INTO id_estado
                FROM sisr_pla_dependencias_administrativas d
                WHERE d.id = id_dependencia;

		RETURN id_estado;
        END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION rrhh_liq_mae_id_estado(integer)
  OWNER TO openerp;
