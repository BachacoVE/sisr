-- Function: rrhh_liq_mae_ultimo_salario_mensual_promediado(integer, integer, integer, date, date)

-- DROP FUNCTION rrhh_liq_mae_ultimo_salario_mensual_promediado(integer, integer, integer, date, date);

CREATE OR REPLACE FUNCTION rrhh_liq_mae_ultimo_salario_mensual_promediado(maestro integer, meses integer, modalidad integer, fecha_fin date, fecha_inicio date)
  RETURNS double precision AS
$BODY$
	DECLARE total_horas INTEGER;
	DECLARE ultimo_salario DOUBLE PRECISION;
        BEGIN
		/*
		SELECT SUM(monto_pago) INTO ultimo_salario 
		FROM for_pis_mae_consolidado_detalle
		WHERE maestro_id = maestro
		GROUP BY maestro_id;
		*/
		
		SELECT sum(monto_pago) INTO ultimo_salario 
		FROM for_pis_mae_consolidado_detalle
		WHERE maestro_id = maestro
		GROUP BY maestro_id, consolidado_id
		ORDER BY consolidado_id DESC
		LIMIT 1;

		SELECT sum(a.horas_lunes)+sum(a.horas_martes)+sum(a.horas_miercoles)+sum(a.horas_jueves)+sum(a.horas_viernes)+sum(a.horas_sabado)+sum(a.horas_domingo) INTO  total_horas
                FROM for_pis_mae_asistencias a
                WHERE a.maestro_id = maestro
                  AND a.semana_desde >= (fecha_inicio - time '24:00')
		  AND a.semana_hasta <= (fecha_fin + time '24:00');
		
		IF meses = 0 THEN
			RETURN (ultimo_salario - ultimo_salario);
		ELSE
			IF modalidad = 3 THEN
				-- Calculo de Ultimo Salario/ meses de antiguedad. Cada mes representa veinte (20) días
				RETURN (ultimo_salario / meses);
			ELSE
				-- Calculo de Ultimo Salario/horas trabajadas * 30
				
				RETURN ((ultimo_salario/total_horas) * 30);
				
			END IF;
		END IF;		
        END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION rrhh_liq_mae_ultimo_salario_mensual_promediado(integer, integer, integer, date, date)
  OWNER TO openerp;

